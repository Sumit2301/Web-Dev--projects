// API Keys
const API_KEY_WEATHER = "89f9c271fc754d4fa83113548251102";
const API_KEY_AQI = "c0ebf58cabc16969ef20e0750776d64983482c0d";
const AI_API_KEY = "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";

// DOM Elements
const cityInput = document.getElementById("cityInput");
const searchBtn = document.getElementById("searchBtn");
const locateBtn = document.getElementById("locateBtn");
const weatherDetails = document.getElementById("weather-details");
const aqiDetails = document.getElementById("aqi-details");
const themeToggle = document.getElementById("themeToggle");
const chatInput = document.getElementById("chatInput");
const sendBtn = document.getElementById("sendBtn");
const messages = document.getElementById("messages");

// Smooth Dark Mode Toggle
function applyTheme(theme) {
    document.body.classList.toggle("dark-mode", theme === "dark");
    localStorage.setItem("theme", theme);
}

themeToggle.addEventListener("click", () => {
    const currentTheme = localStorage.getItem("theme") === "dark" ? "light" : "dark";
    applyTheme(currentTheme);
});

// Apply saved theme on page load
applyTheme(localStorage.getItem("theme") || "light");

// Fetch Weather Data
async function getWeather(city) {
    const url = `https://api.weatherapi.com/v1/forecast.json?key=${API_KEY_WEATHER}&q=${city}&days=5`;
    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error("Weather data fetch failed");
        const data = await response.json();
        const { location, current, forecast } = data;

        weatherDetails.innerHTML = `
            <h3>${location.name}, ${location.country}</h3>
            <p>Temperature: ${current.temp_c}&#8451;</p>
            <p>Condition: ${current.condition.text}</p>
            <img src="https:${current.condition.icon}" alt="Weather Icon">
            <h4>5-Day Forecast</h4>
            <div class="forecast">
                ${forecast.forecastday.map(day => `
                    <div>
                        <p>${day.date}</p>
                        <p>Max: ${day.day.maxtemp_c}&#8451;, Min: ${day.day.mintemp_c}&#8451;</p>
                        <img src="https:${day.day.condition.icon}" alt="${day.day.condition.text}">
                    </div>
                `).join('')}
            </div>
        `;
    } catch (error) {
        weatherDetails.innerHTML = `<p>Error fetching weather data: ${error.message}</p>`;
    }
}

// Fetch AQI Data
async function getAQI(city) {
    const url = `https://api.waqi.info/feed/${city}/?token=${API_KEY_AQI}`;
    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error("AQI data fetch failed");
        const data = await response.json();
        const aqi = data.data.aqi;

        aqiDetails.innerHTML = `
            <p>Current AQI: <span class="${getAQIColor(aqi)}">${aqi}</span></p>
            <p>${getAQIMessage(aqi)}</p>
        `;
    } catch (error) {
        aqiDetails.innerHTML = `<p>Error fetching AQI data: ${error.message}</p>`;
    }
}

function getAQIColor(aqi) {
    if (aqi <= 50) return 'good';
    if (aqi <= 100) return 'moderate';
    if (aqi <= 150) return 'unhealthy-sensitive';
    if (aqi <= 200) return 'unhealthy';
    if (aqi <= 300) return 'very-unhealthy';
    return 'hazardous';
}

function getAQIMessage(aqi) {
    if (aqi <= 50) return 'Air quality is good.';
    if (aqi <= 100) return 'Air quality is moderate.';
    if (aqi <= 150) return 'Unhealthy for sensitive groups.';
    if (aqi <= 200) return 'Unhealthy. Reduce outdoor activities.';
    if (aqi <= 300) return 'Very unhealthy. Stay indoors.';
    return 'Hazardous. Avoid outdoor exposure.';
}

// AI Assistant Interaction
async function handleAIQuery(query) {
    const url = "https://api.cohere.ai/generate";
    const options = {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${AI_API_KEY}` },
        body: JSON.stringify({ prompt: `Answer: ${query}`, model: "command-medium" }),
    };

    try {
        const response = await fetch(url, options);
        if (!response.ok) throw new Error("AI response fetch failed");
        const data = await response.json();
        messages.innerHTML += `<p class="ai-response">${data.text}</p>`;
    } catch (error) {
        messages.innerHTML += `<p class="error">AI Error: ${error.message}</p>`;
    }
}

// Event Listeners
searchBtn.addEventListener("click", () => {
    const city = cityInput.value.trim();
    if (city) {
        getWeather(city);
        getAQI(city);
    }
});

sendBtn.addEventListener("click", () => {
    const query = chatInput.value.trim();
    if (query) {
        messages.innerHTML += `<p class="user-message">${query}</p>`;
        handleAIQuery(query);
        chatInput.value = "";
    }
});

locateBtn.addEventListener("click", () => {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(async (position) => {
            const { latitude, longitude } = position.coords;
            const url = `https://api.weatherapi.com/v1/current.json?key=${API_KEY_WEATHER}&q=${latitude},${longitude}`;
            try {
                const response = await fetch(url);
                if (!response.ok) throw new Error("Location data fetch failed");
                const data = await response.json();
                const city = data.location.name;
                getWeather(city);
                getAQI(city);
            } catch (error) {
                weatherDetails.innerHTML = `<p>Error fetching location data: ${error.message}</p>`;
            }
        });
    } else {
        alert("Geolocation is not supported by this browser.");
    }
});
