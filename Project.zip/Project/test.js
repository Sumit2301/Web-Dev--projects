require("dotenv").config(); // Load API key from .env

const OpenAI = require("openai");

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY, // Securely load API key
});

async function generateText() {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: "Tell me a fun fact about space!" }],
    });

    console.log("Generated Text:", response.choices[0].message.content);
  } catch (error) {
    console.error("Error:", error);
  }
}

generateText();
