const Quiz = require('../models/Quiz');

exports.getQuiz = (req, res) => {
    const { testName } = req.params;

    // Fetch quiz questions based on selected test
    Quiz.getByTestName(testName, (err, result) => {
        if (err) return res.status(500).json({ message: 'Error fetching quiz questions' });
        res.status(200).json(result);
    });
};
