const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const sendMail = require('../config/mailer');

// Register new user
exports.register = (req, res) => {
    const { first_name, last_name, email, password, age, qualification } = req.body;

    User.findByEmail(email, (err, result) => {
        if (result.length > 0) {
            return res.status(400).json({ message: 'Email already in use' });
        }

        const hashedPassword = bcrypt.hashSync(password, 10);

        const userData = { first_name, last_name, email, password: hashedPassword, age, qualification };
        User.create(userData, (err, result) => {
            if (err) return res.status(500).json({ message: 'Error registering user' });

            sendMail(email, 'Welcome to Quiz App', 'Thank you for registering with us.');
            res.status(200).json({ message: 'User registered successfully' });
        });
    });
};

// Login user
exports.login = (req, res) => {
    const { email, password } = req.body;

    User.findByEmail(email, (err, result) => {
        if (result.length === 0) return res.status(400).json({ message: 'Invalid email or password' });

        const user = result[0];
        if (!bcrypt.compareSync(password, user.password)) {
            return res.status(400).json({ message: 'Invalid email or password' });
        }

        const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET, { expiresIn: '1h' });
        res.status(200).json({ message: 'Login successful', token });
    });
};

// Password reset functionality
exports.resetPassword = (req, res) => {
    const { email } = req.body;
    User.findByEmail(email, (err, result) => {
        if (result.length === 0) return res.status(400).json({ message: 'Email not found' });

        const token = jwt.sign({ email }, process.env.JWT_SECRET, { expiresIn: '15m' });
        sendMail(email, 'Password Reset', `To reset your password, use this link: http://localhost:3000/reset-password?token=${token}`);
        res.status(200).json({ message: 'Password reset email sent' });
    });
};
