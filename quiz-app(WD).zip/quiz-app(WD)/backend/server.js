const express = require('express');
const bodyParser = require('body-parser');
const apiRoutes = require('./routes/routes');

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(express.static('frontend')); // Serve static files (HTML, CSS, JS)

app.use('/api', apiRoutes); // API routes

app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
