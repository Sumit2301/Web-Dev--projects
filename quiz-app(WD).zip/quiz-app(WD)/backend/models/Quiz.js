const db = require('../database');

const Quiz = {
    getByTestName: (testName, callback) => {
        const query = 'SELECT * FROM quizzes WHERE test_name = ?';
        db.query(query, [testName], (err, result) => {
            if (err) return callback(err);
            callback(null, result);
        });
    }
};

module.exports = Quiz;
