const db = require('../database');

const User = {
    create: (userData, callback) => {
        const { first_name, last_name, email, password, age, qualification } = userData;
        const query = 'INSERT INTO users (first_name, last_name, email, password, age, qualification) VALUES (?, ?, ?, ?, ?, ?)';
        db.query(query, [first_name, last_name, email, password, age, qualification], (err, result) => {
            if (err) return callback(err);
            callback(null, result);
        });
    },

    findByEmail: (email, callback) => {
        const query = 'SELECT * FROM users WHERE email = ?';
        db.query(query, [email], (err, result) => {
            if (err) return callback(err);
            callback(null, result);
        });
    }
};

module.exports = User;
