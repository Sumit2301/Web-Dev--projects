const express = require('express');
const quizController = require('../controllers/quizController');

const router = express.Router();

router.get('/quiz/:testName', quizController.getQuiz);
router.post('/send-result-email', authController.sendResultEmail);

module.exports = router;
