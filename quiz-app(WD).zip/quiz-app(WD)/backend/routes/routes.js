const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');

// Register route
router.post('/api/register', userController.register);

// Login route
router.post('/api/login', userController.login);

// Request password reset
router.post('/api/reset-password', userController.resetPassword);

// Verify reset token and change password
router.post('/api/reset-password/verify', userController.verifyResetToken);

module.exports = router;
