// Handle Registration
document.getElementById('register-form').addEventListener('submit', function (e) {
    e.preventDefault();
    const formData = {
        first_name: document.getElementById('first_name').value,
        last_name: document.getElementById('last_name').value,
        email: document.getElementById('email').value,
        password: document.getElementById('password').value,
        age: document.getElementById('age').value,
        qualification: document.getElementById('qualification').value
    };

    fetch('http://localhost:3000/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.message === 'User registered successfully') {
            alert('Registration successful! Please check your email for confirmation.');
            window.location.href = 'index.html';  // Redirect to login page
        } else {
            alert('Registration failed');
        }
    });
});

// Handle Login
document.getElementById('login-form').addEventListener('submit', function (e) {
    e.preventDefault();
    const email = document.getElementById('login-email').value; // Corrected to match the ID
    const password = document.getElementById('login-password').value; // Corrected to match the ID

    fetch('http://localhost:3000/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
    })
    .then(response => response.json())
    .then(data => {
        if (data.message === 'Login successful') {
            alert('Login successful!');
            window.location.href = 'quiz.html';  // Redirect to quiz page
        } else {
            alert('Login failed');
        }
    });
});

// Handle Quiz Start
document.getElementById('start-quiz').addEventListener('click', function () {
    const testName = document.getElementById('test-dropdown').value;

    fetch(`http://localhost:3000/api/quiz/${testName}`)
        .then(response => response.json())
        .then(data => {
            displayQuiz(data);
        });
});

function displayQuiz(questions) {
    const quizContainer = document.getElementById('quiz-container');
    quizContainer.innerHTML = ''; // Clear previous quiz

    questions.forEach((question, index) => {
        const questionHTML = `
            <div class="question">
                <p>${index + 1}. ${question.question_text}</p>
                <input type="radio" name="question-${index}" value="A" /> ${question.option_A} <br />
                <input type="radio" name="question-${index}" value="B" /> ${question.option_B} <br />
                <input type="radio" name="question-${index}" value="C" /> ${question.option_C} <br />
                <input type="radio" name="question-${index}" value="D" /> ${question.option_D} <br />
            </div>
        `;
        quizContainer.innerHTML += questionHTML;
    }
    );
    quizContainer.innerHTML += `<button id="submit-quiz">Submit</button>`;

    document.getElementById('submit-quiz').addEventListener('click', function () {
        submitQuiz(questions);
    });
}

function submitQuiz(questions) {
    let score = 0;

    questions.forEach((question, index) => {
        const selectedAnswer = document.querySelector(`input[name="question-${index}"]:checked`);
        if (selectedAnswer && selectedAnswer.value === question.correct_answer) {
            score++;
        }
    });

    displayResult(score, questions.length);
}

function displayResult(score, totalQuestions) {
    const resultContainer = document.getElementById('quiz-container');
    resultContainer.innerHTML = `<h2>Your score: ${score} / ${totalQuestions}</h2>`;

    // Send the result via email
    sendResultEmail(score, totalQuestions);
}

function sendResultEmail(score, totalQuestions) {
    fetch('http://localhost:3000/api/send-result-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ score, totalQuestions })
    })
    .then(response => response.json())
    .then(data => alert('Result sent via email.'));
}
